package com.Cars;

public class Adminpage extends Car_Details {
	public static void main(String[] args) throws Exception {
		boolean rep=true;
		while(rep) {
			try {
				System.out.println("Welcome Admin");
			System.out.println("Enter your crendentials for login: ");
			Credentials();
			rep=false;
			System.out.println("successfully logged in ");
		}
		catch(Exception e) {
			System.out.println("wrong login credentials");
			rep=true;
			}
	}
	while(true) {
		System.out.println("Enter your choice:");
		System.out.println("1:Insert 2:select 3:delete 4:update");
		int choice=sc.nextInt();
		switch(choice){
		case 1:
			insertRecord();
			
			break;
		case 2:
			showRecord();
			break;
		case 3:
			updateRecord();
			break;
		case 4:
			deleteRecord();
			break;
		case 5:
			System.out.println("Exited successfully");
			System.exit(0);
			break;
		}
		}
		
	}
}


