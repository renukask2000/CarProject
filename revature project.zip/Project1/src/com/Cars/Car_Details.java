package com.Cars;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.CallableStatement;

public class Car_Details{
	 protected static Connection con  = null;
	 protected static Scanner sc = new Scanner(System.in);
		public static void Credentials() throws Exception{
		
			System.out.println("Enter the username:");
			final String user=sc.next();
			System.out.println("Enter the password:");
			final String password=sc.next();
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/CarProject";
		con=DriverManager.getConnection(url,user,password);
		
		}

	protected static void insertRecord() throws Exception {
		System.out.println("Enter the number of records to insert :");
		int n=sc.nextInt();
		int i=1;
		while(i<=n) {
			System.out.println("Enter the car details");
			String s1="insert into Details values(?,?,?,?,?)";
			PreparedStatement pre=con.prepareStatement(s1);
			System.out.println("Enter the ID");
			int ID=sc.nextInt();
			System.out.println("Enter the CarModel");
			String CarModel=sc.next();
			System.out.println("Enter the CarColour");
			String CarColour=sc.next();
			System.out.println("Enter the CarAddress");
			String CarAddress=sc.next();
			System.out.println("Enter the CarCity");
			String CarCity=sc.next();
			pre.setInt(1, ID);
			pre.setString(2, CarModel);
			pre.setString(3, CarColour);
			pre.setString(4, CarAddress);
			pre.setString(5, CarCity);
			int rows =pre.executeUpdate();
			if(rows>0) {
				System.out.println("Record inserted successfully");
				System.out.println();
			}
			i++;
		}
	}
	protected static void showRecord() throws Exception {
			System.out.println("Collecting Car Details:");
			System.out.println();
			String sq="select * from Details";
	        Statement st=con.createStatement();
			ResultSet rt=st.executeQuery(sq);
			while(rt.next())
			{
				System.out.println(rt.getString(1)+ " ||" + rt.getString(2)+ " ||" + rt.getString(3)+ " || " + rt.getString(4)+ " || " +rt.getString(5) );
			}
			}
	protected static void updateRecord() throws Exception {
		int ID=sc.nextInt();
		String CarModel=sc.next();
		String sql="update Details set ID=? where CarModel=?";
		PreparedStatement pq=con.prepareStatement(sql);
		pq.setInt(1, ID);
		pq.setString(2, CarModel);
		int rows=pq.executeUpdate();
		if(rows>0);
		{
		System.out.println("Record updated successfully");
	}
		String sq="select * from Details";
     Statement st=con.createStatement();
     ResultSet rt=st.executeQuery(sq);
		while(rt.next()){
			System.out.println(rt.getString(1)+ " ||" + rt.getString(2)+ " ||" + rt.getString(3)+ " || " + rt.getString(4)+ " || " +rt.getString(5) );
		}
		}
	
	protected static void deleteRecord() throws Exception {
		int ID=sc.nextInt();
		String sql="delete from Details where Id=?";
		PreparedStatement pq=con.prepareStatement(sql);
		pq.setInt(1, ID);
		int rows=pq.executeUpdate();
		if(rows>0);
		{
		System.out.println("Record deleted successfully");
	}
		String sq="select * from Details";
	     Statement st=con.createStatement();
	     ResultSet rt=st.executeQuery(sq);
			while(rt.next()){
				System.out.println(rt.getString(1)+ " ||" + rt.getString(2)+ " ||" + rt.getString(3)+ " || " + rt.getString(4)+ " || " +rt.getString(5) );
			}
			}
	}
		
		
		
		
	


